window.onload = customize;
Code = "";

function customize() {
	try {
		Code = window.location.href.substring(35);
	} catch(err) {	}
}

function sendRequest()
{
    var q_str = 'type=number';
	doAjax('MyDBox',q_str,'sendRequest_back','post',0);
}

function sendRequest_back(result)
{
	window.location = result;
}

function getAccount()
{
    var q_str = 'code='+Code;
	doAjax('MyDBox',q_str,'getAccount_back','get',0);
}

function getAccount_back(result)
{
	   window.document.getElementById('t2').value=""+result;
}

function uploadFile()
{
	var q_str = 'type=file&path='+document.getElementById('f1').value;
	doAjax('MyDBox',q_str,'uploadFile_back','post',0);
}

function uploadFile_back(result)
{
	   window.document.getElementById('t1').value=""+result;
}

function getUserStorage()
{
	var q_str = 'type=storage';
	doAjax('MyDBox',q_str,'getUserStorage_back','post',0);
}

function getUserStorage_back(result)
{
	   window.document.getElementById('t3').value=""+result;
}

function count()
{
	var q_str = 'type=count';
	doAjax('MyDBox',q_str,'count_back','post',0);
}

function count_back(result)
{
	   window.document.getElementById('t4').value=""+result;
}

function createFolder()
{
	var q_str = 'type=create&folder='+document.getElementById('t6').value;
	doAjax('MyDBox',q_str,'createFolder_back','post',0);
}

function createFolder_back(result)
{
	   window.document.getElementById('t7').value=""+result;
}