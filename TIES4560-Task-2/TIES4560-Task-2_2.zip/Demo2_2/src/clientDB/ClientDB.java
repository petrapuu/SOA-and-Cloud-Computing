package clientDB;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
//import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.json.*;

public class ClientDB {

	public ClientDB() {
	}

	private static String queryResult = "";

	public String sendRequest() throws URISyntaxException, IOException {
		String appKey = "wky7j2ghd0lkl70"; // get from AppConsole when create the DropBox App
		String redirectURI = "http://localhost:8080/Demo22/"; // any url to where you want to redirect the user
		URI uri = new URI("https://www.dropbox.com/oauth2/authorize");
		StringBuilder requestUri = new StringBuilder(uri.toString());
		requestUri.append("?client_id=");
		requestUri.append(URLEncoder.encode(appKey, "UTF-8"));
		requestUri.append("&response_type=code");
		requestUri.append("&redirect_uri=" + redirectURI.toString());
		queryResult = requestUri.toString();
		return queryResult;
	}

	public String accessToken(String codeStr) throws URISyntaxException, IOException {
		String code = "" + codeStr; // code get from previous step
		String appKey = "wky7j2ghd0lkl70"; // get from AppConsole when create the DropBox App
		String appSecret = "sst0t5rvpq8jyun"; // get from AppConsole when create the DropBox App
		String redirectURI = "http://localhost:8080/Demo22/"; // any url to where you want to redirect the user

		StringBuilder tokenUri = new StringBuilder("code=");
		tokenUri.append(URLEncoder.encode(code, "UTF-8"));
		tokenUri.append("&grant_type=");
		tokenUri.append(URLEncoder.encode("authorization_code", "UTF-8"));
		tokenUri.append("&client_id=");
		tokenUri.append(URLEncoder.encode(appKey, "UTF-8"));
		tokenUri.append("&client_secret=");
		tokenUri.append(URLEncoder.encode(appSecret, "UTF-8"));
		tokenUri.append("&redirect_uri=" + redirectURI);
		URL url = new URL("https://api.dropboxapi.com/oauth2/token");
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		try {
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			connection.setRequestProperty("Content-Length", "" + tokenUri.toString().length());
			
			OutputStreamWriter outputStreamWriter = new OutputStreamWriter(connection.getOutputStream());
			outputStreamWriter.write(tokenUri.toString());
			outputStreamWriter.flush();
			
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream())); // ,Charset.forName("UTF-8")
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			queryResult = response.toString();
		} finally {
			connection.disconnect();
		}
		return queryResult;
	}

	public static String parseToken(String result) {
		JSONObject obj = new JSONObject(result);
		String c = obj.getString("access_token");

		return c;
	}

	public static String parseAccountID(String result) {
		JSONObject obj = new JSONObject(result);
		String c = obj.getString("account_id");

		return c;
	}

	public static String getAccountInfo(String tokenStr, String accountIDStr) throws URISyntaxException, IOException {
		String access_token = "" + tokenStr;
		String content = "{\"account_id\": \"" + accountIDStr + "\"}";
		URL url = new URL("https://api.dropboxapi.com/2/users/get_account");
		
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		try {
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Authorization", "Bearer " + access_token);
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setRequestProperty("Content-Length", "" + content.length());
			OutputStreamWriter outputStreamWriter = new OutputStreamWriter(connection.getOutputStream());
			outputStreamWriter.write(content);
			outputStreamWriter.flush();
			
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			queryResult = response.toString();
		} finally {
			connection.disconnect();
		}
		return parseAccountInfo(queryResult);
	}

	private static String parseAccountInfo(String result) {
		JSONObject obj = new JSONObject(result);
		String accountId = obj.getString("account_id");
		String displayName = obj.getJSONObject("name").getString("display_name");
		String email = obj.getString("email");
		return "ID: " + accountId + ", name: " + displayName + ", email: " + email;
	}

	public String uploadFile(String token, String path) throws URISyntaxException, IOException {
		int i = path.lastIndexOf("\\");
		String fileName = path.substring(i + 1);
		String access_token = "" + token;
		String sourcePath = "" + path;
		Path pathFile = Paths.get(sourcePath);
		byte[] data = Files.readAllBytes(pathFile);
		String content = "{\"path\": \"/Demo22/" + fileName + "\",\"mode\":\"add\",\"autorename\": true,\"mute\": false,\"strict_conflict\": false}";
		URL url = new URL("https://content.dropboxapi.com/2/files/upload");
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		try {
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Authorization", "Bearer " + access_token);
			connection.setRequestProperty("Content-Type", "application/octet-stream");
			connection.setRequestProperty("Dropbox-API-Arg", "" + content);
			connection.setRequestProperty("Content-Length", String.valueOf(data.length));
			OutputStream outputStream = connection.getOutputStream();
			outputStream.write(data);
			outputStream.flush();
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			queryResult = response.toString();
		} finally {
			connection.disconnect();
		}
		return "File uploaded";
	}

	public String getSpaceUsage(String tokenStr) throws URISyntaxException, IOException {
		String access_token = "" + tokenStr;
		String a = "aaa";
		URL url = new URL("https://api.dropboxapi.com/2/users/get_space_usage");
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		try {
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Authorization", "Bearer " + access_token);
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			a = response.toString();
		} finally {
			connection.disconnect();
		}
		return parseSpaceUsage(a);
	}

	private static String parseSpaceUsage(String a) {
		String delims = "[ ]+";
		String[] tokens = a.split(delims);
		String result = "";
		for (int i = 0; i < tokens.length; i++) {
			if (Character.isDigit(tokens[i].charAt(0))) {
				result = result + tokens[i] + " ";
			}
		}
		result = result.replace(",", "");
		result = result.replace(".", "");
		result = result.replace("}", "");
		String[] b = result.split(delims);
		double b0 = Double.parseDouble(b[0]);
		double b1 = Double.parseDouble(b[1]);
		double bb0 = b0/1048576;
		double bb1 = b1/1048576;
		double ratio = (bb0/bb1)*100;
		Double.toString(bb0);
		Double.toString(bb1);
		Double.toString(ratio);
		return "Used space: " + String.format("%.2f", bb0) + " MB, Total space: " + String.format("%.2f", bb1) + " MB, Percentage used:" + String.format("%.2f", ratio) + "%";
	}
	
	public String count(String tokenStr) throws URISyntaxException, IOException {
		String access_token = "" + tokenStr;
		String a = "aaa";
		URL url = new URL("https://api.dropboxapi.com/2/file_requests/count");
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		
		try {
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Authorization", "Bearer " + access_token);
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			a = response.toString();
		} finally {
			connection.disconnect();
		}
		return parseFileRequestCount(a);
	}
	
	private static String parseFileRequestCount(String a) {
		String delims = "[ ]+";
		String[] tokens = a.split(delims);
		String result = tokens[1];
		result = result.replace("}", "");
		return result;
	}
	
	public String createFolder(String tokenStr, String foldername) throws URISyntaxException, IOException {
		String access_token = "" + tokenStr;
		String content = "{\"path\": \"/Demo22/" + foldername + "\",\"autorename\": false}";
		URL url = new URL("https://api.dropboxapi.com/2/files/create_folder_v2");
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		
		try {
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Authorization", "Bearer " + access_token);
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setRequestProperty("Content-Length", "" + content.length());
			
			OutputStreamWriter outputStreamWriter = new OutputStreamWriter(connection.getOutputStream());
			outputStreamWriter.write(content);
			outputStreamWriter.flush();
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			queryResult = response.toString();
		} finally {
			connection.disconnect();
		}
		return "Folder created";
	}
}