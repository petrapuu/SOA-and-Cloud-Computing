package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URISyntaxException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import clientDB.ClientDB;

/**
 * Servlet implementation class MyConvertor_Servlet
 */
@WebServlet("/MyDBox")
public class MyDBox extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String token = "";
	private static String id = "";

	/**
	 * 
	 * @see HttpServlet#HttpServlet()
	 * 
	 */
	public MyDBox() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		ClientDB client = new ClientDB();
		String result;
		String account;
		String code = request.getParameter("code").toString();
		try {
			result = client.accessToken(code);
			token = ClientDB.parseToken(result);
			id = ClientDB.parseAccountID(result);
			account = ClientDB.getAccountInfo(token, id);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = "virhe";
			token = "virhe";
			account = "virhe";
		}
		PrintWriter out = response.getWriter();
		out.write(account);
		out.flush();
		out.close();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String type = request.getParameter("type").toString();
		ClientDB client = new ClientDB();
		String result = "";
		String folder = "";

		if (type.equals("file")) {
			String path = request.getParameter("path").toString();
			try {
				result = client.uploadFile(token, path);
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				result = "virhe";
			}
		} else if (type.equals("count")) {
			try {
				result = client.count(token);
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				result = "virhe";
			}
		} else if (type.equals("create")) {
			try {
				folder = request.getParameter("folder").toString();
				result = client.createFolder(token, folder);
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				result = "virhe";
			}
		}else if (type.equals("storage")) {
			try {
				result = client.getSpaceUsage(token);
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				result = "virhe";
			}
		} else {
			try {
				result = client.sendRequest();
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				result = "virhe";
			}
		}
		PrintWriter out = response.getWriter();
		out.write(result);
		out.flush();
		out.close();
	}
}