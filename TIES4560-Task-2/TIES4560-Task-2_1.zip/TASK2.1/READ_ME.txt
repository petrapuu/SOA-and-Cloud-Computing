1. From SimpleTestProject run Exporter.java as Java application.
2. From jettyexample run RunServlets.java as Java application.
3. Open Postman as client.
   Use http://localhost:5000/rooms
   Use http://localhost:5000/room (GET to get a room/POST to add a room)
   Use http://localhost:5000/update
   Use http://localhost:5000/delete

Parameters 'id', 'name' and 'cap'(= room capacity).