package myRooms;

public class Room {
	private int id;
	private String roomName;
	private int capacity;
	
	public Room(int id, String roomName, int capacity) {
		this.id = id;
		this.roomName = roomName;
		this.capacity = capacity;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id=id;
	}
	
	public String getRoomName() {
		return roomName;
	}
	
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	public String toString() {
		return "Room id: " + getId() + ", Room name: " + getRoomName() + ", Room capacity: " + getCapacity();
	}
}
