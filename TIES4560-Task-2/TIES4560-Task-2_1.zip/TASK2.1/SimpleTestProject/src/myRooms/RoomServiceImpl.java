package myRooms;

import java.util.HashMap;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService(endpointInterface = "myRooms.RoomService")
public class RoomServiceImpl implements RoomService{

	private HashMap<Integer, Room> roomMap = new HashMap<Integer, Room>();
	
	public RoomServiceImpl() {
		if (roomMap.isEmpty()) {
			roomMap.put(1, new Room(1, "Blue", 10));
			roomMap.put(2, new Room(2, "Red", 20));
			roomMap.put(3, new Room(3, "Yellow", 6));
			roomMap.put(4, new Room(4, "Green", 4));
		}
	}
	
	@Override
	@WebMethod
	public String getRooms() {
		String rooms = "";

		for(Room room : roomMap.values()) {
			rooms = rooms + room.toString() + "#";
		}
		return rooms;
	}

	@Override
	@WebMethod
	public boolean addRoom(String name, int capacity) {
		int id = getMaxId() + 1;
		Room room = new Room(id, name, capacity);
		roomMap.put(id, room);
		return true;
	}

	@Override
	@WebMethod
	public boolean updateRoom(int id, String name, int capacity) {
		Room room = roomMap.get(id);
		if (room == null) return false;
		
		if (!name.isEmpty()) room.setRoomName(name);
		if (!(capacity == -1)) room.setCapacity(capacity);
		return true;
	}

	@Override
	@WebMethod
	public boolean deleteRoom(int id) {
		if (roomMap.remove(id) != null) return true;
		return false;
	}

	@Override
	@WebMethod
	public String getRoom(int id) {
		Room room = roomMap.get(id);
		if (room != null) return room.toString();
		else return "";
	}
	
	
	/** Method that finds the highest id value from the roomMap.
	 * @return Highest value from the map.
	 */
	public int getMaxId() {
		int max = 0;
		for (int id : roomMap.keySet()) {
			if (max <= id) max = id;
		}
		return max;
	}
}
