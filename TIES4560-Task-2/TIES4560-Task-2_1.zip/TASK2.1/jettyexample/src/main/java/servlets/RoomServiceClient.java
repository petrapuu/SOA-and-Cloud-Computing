package servlets;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebServiceException;

import myRooms.RoomService;;

public class RoomServiceClient {

	// URL that client uses to connect to Web Server.
	private String strUrl = "http://localhost:8888/MyRoomService/roomservice?wsdl";
	private String qnamePar1 = "http://myRooms/";
	private String qnamePar2 = "RoomServiceImplService";
	
	public RoomService createService() {
		
		RoomService roomservice = null;
		try {
			URL url = new URL(strUrl);
			QName qname = new QName(qnamePar1, qnamePar2);
			Service service = Service.create(url, qname);
			roomservice = service.getPort(RoomService.class);
			return roomservice;
		} catch (WebServiceException wse) {
			wse.printStackTrace();
			return roomservice;
		} catch (Exception e) {
			e.printStackTrace();
			return roomservice;
		}
		
	}
}
