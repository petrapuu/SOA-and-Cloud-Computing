package servlets;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;


public class RunServlets {

	public static void main(String[] args) {

		Server server = new Server(5000);
        ServletContextHandler handler = new ServletContextHandler(server, "/");
        handler.addServlet(ShowRoomsServlet.class, "/rooms");
        handler.addServlet(GetAndAddRoomServlet.class, "/room");
        handler.addServlet(DeleteRoomServlet.class, "/delete");
        handler.addServlet(UpdateRoomServlet.class, "/update");
        try {
			server.start();
			server.dumpStdErr();
			server.join();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
