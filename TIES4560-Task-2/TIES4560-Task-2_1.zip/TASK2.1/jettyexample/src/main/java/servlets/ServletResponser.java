package servlets;

import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import org.eclipse.jetty.http.HttpStatus;

/**
 * A class that handles responsing to client.
 */
public class ServletResponser {

	public void invalidIdToUpdate(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.BAD_REQUEST_400);
        response.getWriter().write("ERROR: Use parameter {id} to update a room with specific id.");
	}

	public void idMustBeInteger(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.BAD_REQUEST_400);
        response.getWriter().write("ERROR: Value of id must be an integer.");
	}

	public void noNewValuesWereGiven(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.BAD_REQUEST_400);
        response.getWriter().write("ERROR: No new values were given.");
	}

	public void capacityMustBeInteger(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.BAD_REQUEST_400);
        response.getWriter().write("ERROR: Value of capacity must be an integer.");
	}

	public void noRoomFound(HttpServletResponse response, int idInt) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.NOT_ACCEPTABLE_406);
        response.getWriter().write("ERROR: Room service doesn't have a room with id " + idInt + ".");
	}

	public void roomUpdateSuccess(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.ACCEPTED_202);
        response.getWriter().write("Room was updated succesfully!");
	}

	public void failedToConnect(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.BAD_GATEWAY_502);
        response.getWriter().write("ERROR: Failed to connect to Web Server.");
	}

	public void invalidIdToRemove(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.BAD_REQUEST_400);
        response.getWriter().write("ERROR: Use parameter {id} to remove a room with specific id.");
	}

	public void roomDeletedSuccess(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.ACCEPTED_202);
        response.getWriter().write("Room was deleted succesfully!");
	}

	public void noIdToGetRoom(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.BAD_REQUEST_400);
        response.getWriter().write("ERROR: Use parameter {id} to get room's information.");
	}

	public void giveRoomInfo(HttpServletResponse response, String room) throws IOException {
		response.setStatus(HttpStatus.ACCEPTED_202);
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(room);
	}

	public void infoToAddNewRoom(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.BAD_REQUEST_400);
        response.getWriter().write("ERROR: To add a new room use parameter {name} "
        		+ "to add room's name and {cap} to add room's capacity.");
	}

	public void couldNotAddRoom(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.NOT_ACCEPTABLE_406);
        response.getWriter().write("ERROR: Could not add room.");
	}

	public void roomAddSuccess(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.ACCEPTED_202);
        response.getWriter().write("Room added succesfully!");
	}

}
