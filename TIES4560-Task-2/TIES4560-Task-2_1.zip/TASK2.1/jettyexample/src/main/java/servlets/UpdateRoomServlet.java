package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import myRooms.RoomService;

@WebServlet
public class UpdateRoomServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	public UpdateRoomServlet() {
		super();
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RoomServiceClient client = new RoomServiceClient();
		RoomService roomservice = client.createService();
		ServletResponser responser = new ServletResponser();
		
		// If we can connect then we continue.
		if (roomservice != null) {
			
			// Asking needed values from request
			String idStr = request.getParameter("id");
			String nameStr = request.getParameter("name");
			String capStr = request.getParameter("cap");
			
			// Checking that id value is valid
			if (idStr == null) {
				responser.invalidIdToUpdate(response);
		        return;
			}
			int idInt;
			try {
				idInt = Integer.parseInt(idStr);
			} catch (NumberFormatException nfe) {
				responser.idMustBeInteger(response);
				return;
			}
			
			// Checking if user gave any new values	
			if (nameStr == null && capStr == null) {
				responser.noNewValuesWereGiven(response);
				return;
			}
			
			// Checking values seperately
			if (nameStr == null) nameStr = "";
			int capInt = -1;
			if (!(capStr == null)) {
				try {
					capInt = Integer.parseInt(capStr);
				} catch (NumberFormatException nfe) {
					responser.capacityMustBeInteger(response);
					return;
				}
			}
			if (!roomservice.updateRoom(idInt, nameStr, capInt)) {
				responser.noRoomFound(response, idInt);
				return;
			} else {
				responser.roomUpdateSuccess(response);
			}
		}
		else {
			responser.failedToConnect(response);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
