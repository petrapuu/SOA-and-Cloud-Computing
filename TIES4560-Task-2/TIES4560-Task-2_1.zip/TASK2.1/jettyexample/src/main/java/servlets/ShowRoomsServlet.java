package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jetty.http.HttpStatus;

import myRooms.RoomService;

@WebServlet
public class ShowRoomsServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	public ShowRoomsServlet() {
		super();
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RoomServiceClient client = new RoomServiceClient();
		RoomService roomservice = client.createService();
		ServletResponser responser = new ServletResponser();
		
		// If we can connect then we continue.
		if (roomservice != null) {
			
			String rooms = roomservice.getRooms();
			String[] roomArray = parseRooms(rooms);
			
			response.setStatus(HttpStatus.ACCEPTED_202);
			response.setCharacterEncoding("UTF-8");
			
			PrintWriter writer = response.getWriter();
			writer.println("Room service's rooms are:");
			for(String room : roomArray) {
				writer.println(room);
	        }
		}
		else {
			responser.failedToConnect(response);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private String[] parseRooms(String rooms){
		return rooms.split("#");
	}
}
