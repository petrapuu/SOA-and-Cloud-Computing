package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import myRooms.RoomService;

@WebServlet
public class DeleteRoomServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	public DeleteRoomServlet() {
		super();
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RoomServiceClient client = new RoomServiceClient();
		RoomService roomservice = client.createService();
		ServletResponser responser = new ServletResponser();
		
		// If we can connect then we continue.
		if (roomservice != null) {
			
			// Requesting id from request and making verifications before deleting a room.
			String deleteStr = request.getParameter("id");
			if (deleteStr == null) {
				responser.invalidIdToRemove(response);
		        return;
			}
			int deleteInt;
			try {
				deleteInt = Integer.parseInt(deleteStr);
			} catch (NumberFormatException nfe) {
				responser.capacityMustBeInteger(response);
				return;
			}
			if (!roomservice.deleteRoom(deleteInt)) {
				responser.noRoomFound(response, deleteInt);
				return;
			} else {
				responser.roomDeletedSuccess(response);
			}
		}
		else {
			responser.failedToConnect(response);
		}
	}
	

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
