package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import myRooms.RoomService;

@WebServlet
public class GetAndAddRoomServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	public GetAndAddRoomServlet() {
		super();
	}
	
	// Method that gets information of one room.
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RoomServiceClient client = new RoomServiceClient();
		RoomService roomservice = client.createService();
		ServletResponser responser = new ServletResponser();
		
		// If we can connect then we continue.
		if (roomservice != null) {
			
			// Requesting id from request and making verifications before trying
			// to get room information.
			String roomid = request.getParameter("id");
			if (roomid == null) {
				responser.noIdToGetRoom(response);
		        return;
			}
		
			int id = -1;
			try {
				id = Integer.parseInt(roomid);
			} catch (NumberFormatException nfe) {
				nfe.printStackTrace();
				responser.idMustBeInteger(response);
				return;
			}
			
			String room = roomservice.getRoom(id);
			if (room.isEmpty()) {
				responser.noRoomFound(response, id);
		        return;
			}
			responser.giveRoomInfo(response, room);
		}
		else {
			responser.failedToConnect(response);
		}
	}

	// Method that adds a new room to the Room Service.
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RoomServiceClient client = new RoomServiceClient();
		RoomService roomservice = client.createService();
		ServletResponser responser = new ServletResponser();
		
		// If we can connect then we continue.
		if (roomservice != null) {
			
			// Requesting parameters from request and making verifications before trying
			// to add a new room.
			String name = request.getParameter("name");
			String capacity = request.getParameter("cap");
			
			if (name == null || capacity == null) {
				responser.infoToAddNewRoom(response);
		        return;
			}
			int intCap;
			try {
				intCap = Integer.parseInt(capacity);
			} catch (NumberFormatException nfe) {
				responser.capacityMustBeInteger(response);
				return;
			}
			if (!roomservice.addRoom(name, intCap)) {
				responser.couldNotAddRoom(response);
				return;
			} else {
				responser.roomAddSuccess(response);
			}
		}
		else {
			responser.failedToConnect(response);
		}
	}
}
